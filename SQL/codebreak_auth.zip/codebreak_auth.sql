-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           5.0.67-community-nt - MySQL Community Edition (GPL)
-- Serveur OS:                   Win32
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Export de la structure de la base pour codebreak_auth
DROP DATABASE IF EXISTS `codebreak_auth`;
CREATE DATABASE IF NOT EXISTS `codebreak_auth` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `codebreak_auth`;


-- Export de la structure de table codebreak_auth. account
DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `Id` bigint(20) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL,
  `Pseudo` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Power` int(11) NOT NULL,
  `CreationDate` datetime NOT NULL,
  `LastConnectionDate` datetime NOT NULL,
  `LastConnectionIP` varchar(16) NOT NULL,
  `RemainingSubscription` datetime NOT NULL,
  `Banned` tinyint(1) NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Export de données de la table codebreak_auth.account: 8 rows
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`Id`, `Name`, `Pseudo`, `Password`, `Power`, `CreationDate`, `LastConnectionDate`, `LastConnectionIP`, `RemainingSubscription`, `Banned`) VALUES
	(2, 'Smarken', 'Smarken123', '10151813', 1, '2014-08-09 23:51:23', '2014-08-09 23:51:23', '0.0.0.0', '2014-08-09 23:51:23', 0),
	(5, 'Test', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0),
	(8, 'Test1', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0),
	(10, 'test2', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0),
	(12, 'test3', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0),
	(13, 'test4', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0),
	(14, 'test5', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0),
	(15, 'test6', 'test123', 'test', 0, '2014-08-09 00:00:00', '2014-08-09 00:00:00', '0.0.0.0', '2014-08-09 00:00:00', 0);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
