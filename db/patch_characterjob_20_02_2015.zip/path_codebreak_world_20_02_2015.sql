-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           5.6.20 - MySQL Community Server (GPL)
-- Serveur OS:                   Win32
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Export de la structure de la base pour codebreak_world
CREATE DATABASE IF NOT EXISTS `codebreak_world` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `codebreak_world`;


-- Export de la structure de table codebreak_world. characterjob
CREATE TABLE IF NOT EXISTS `characterjob` (
  `Id` bigint(20) NOT NULL,
  `JobId` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  `Experience` int(11) NOT NULL,
  `Options` int(11) NOT NULL,
  PRIMARY KEY (`Id`,`JobId`),
  CONSTRAINT `FK_CharacterJob_Character` FOREIGN KEY (`Id`) REFERENCES `characterinstance` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Export de données de la table codebreak_world.characterjob: ~0 rows (environ)
/*!40000 ALTER TABLE `characterjob` DISABLE KEYS */;
/*!40000 ALTER TABLE `characterjob` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
